/**
 * INE Store — Standalone Price/Stock Scraper (Step 2)
 * ----------------------------------------------------
 * Goal: given one product page on demo.inelabteamdev.com, reliably get
 * that product's live price + stock by driving a real headless browser
 * through the site's anti-bot challenge:
 *   1. Dismiss the cookie-consent modal if/when it appears (random delay,
 *      random position, sometimes needs 2-3 clicks).
 *   2. Simulate genuine mouse movement + a 600ms+ hover over the price
 *      panel (the "Check today's price" button stays disabled until the
 *      site sees 8+ mousemove events and the hover).
 *   3. Click "Check today's price".
 *   4. Wait for the panel to resolve to EITHER its success state or its
 *      error state — never on a fixed timer. The click has a ~35% chance
 *      of silently doing nothing or adding ~900ms delay, so the wait must
 *      be generous and must not assume success.
 *
 * IMPORTANT — SELECTORS ARE PLACEHOLDERS:
 * I could not load the live store from my sandbox (it's a React SPA and
 * my container's network doesn't reach demo.inelabteamdev.com), so the
 * CSS selectors below are best-guess placeholders based on the brief's
 * description, not verified against the real DOM. Every place you need
 * to check/replace a selector is marked with "VERIFY:" — open the product
 * page in Chrome, press F12 -> Inspect, click the real element, and copy
 * its actual selector (prefer a data-testid or id if one exists; fall
 * back to a stable class name or text content).
 *
 * This script is intentionally standalone (no retry loop, no DB writes —
 * that's Step 3 and Step 4). Run it directly against one product until it
 * reliably returns a price.
 */

import { chromium } from 'playwright';

// ---------------------------------------------------------------------
// CONFIG — fill these in for the product you're testing against
// ---------------------------------------------------------------------
const STORE_BASE_URL = 'https://demo.inelabteamdev.com';

// VERIFY: confirm the real product page URL pattern (e.g. /product/{id}
// or /products/{id}?option={optionId}). Check what the site's own router
// does when you click a product in the UI, then match it here.
const PRODUCT_PATH = '/product/REPLACE_WITH_PRODUCT_ID';

const HEADLESS = process.env.HEADLESS !== 'false'; // `HEADLESS=false npm run scrape` for headed/demo mode

// ---------------------------------------------------------------------
// SELECTORS — every one of these needs verifying against the live DOM
// ---------------------------------------------------------------------
const SELECTORS = {
  // VERIFY: the cookie-consent modal container. Look for a dialog/banner
  // that appears 1.5-5s after page load.
  cookieConsentModal: '[data-testid="cookie-consent"], .cookie-consent, [role="dialog"]',

  // VERIFY: the modal's dismiss/accept button, inside that modal.
  cookieConsentDismissBtn: '[data-testid="cookie-consent-accept"], .cookie-consent button',

  // VERIFY: the price panel area you need to move the mouse over/hover.
  // This is whatever wraps the "Check today's price" button + price display.
  pricePanel: '[data-testid="price-panel"], .price-panel',

  // VERIFY: the "Check today's price" button itself.
  checkPriceButton: '[data-testid="check-price-button"], button:has-text("Check today\'s price")',

  // VERIFY: the element that appears on SUCCESS, containing the resolved
  // price and stock text.
  priceSuccessState: '[data-testid="price-success"], .price-result.success',
  priceValue: '[data-testid="price-value"], .price-value',
  stockValue: '[data-testid="stock-value"], .stock-value',

  // VERIFY: the element that appears on ERROR/failure.
  priceErrorState: '[data-testid="price-error"], .price-result.error',
};

const TIMEOUTS = {
  cookieModalAppear: 6000, // modal can appear up to 5s after load
  priceResolve: 15000, // generous: button click can add ~900ms delay, plus PoW solve time
};

// ---------------------------------------------------------------------
// Step helpers
// ---------------------------------------------------------------------

/**
 * Dismisses the cookie consent modal if it shows up. It appears after a
 * random 1.5-5s delay and sometimes needs 2-3 clicks to fully go away,
 * so this polls briefly and clicks repeatedly while it's visible.
 */
async function dismissCookieConsentIfPresent(page) {
  try {
    const modal = page.locator(SELECTORS.cookieConsentModal).first();
    await modal.waitFor({ state: 'visible', timeout: TIMEOUTS.cookieModalAppear });
    console.log('[cookie] Consent modal appeared — dismissing...');

    // Click up to 3 times, since the brief says it sometimes needs 2-3 clicks.
    for (let i = 0; i < 3; i++) {
      const stillVisible = await modal.isVisible().catch(() => false);
      if (!stillVisible) break;
      const dismissBtn = page.locator(SELECTORS.cookieConsentDismissBtn).first();
      await dismissBtn.click({ timeout: 3000 }).catch(() => {});
      await page.waitForTimeout(300);
    }
    console.log('[cookie] Consent modal dismissed (or no longer blocking).');
  } catch {
    // Modal never appeared within the window — that's fine, it's random.
    console.log('[cookie] No consent modal appeared within the wait window — continuing.');
  }
}

/**
 * The "Check today's price" button stays disabled until the site has seen
 * 8+ mousemove events AND a 600ms+ hover over the price area. This moves
 * the mouse in several small steps toward the panel (never one instant
 * jump), then holds there past 600ms.
 */
async function simulateGenuineMouseMovement(page) {
  const panel = page.locator(SELECTORS.pricePanel).first();
  await panel.waitFor({ state: 'visible', timeout: 10000 });
  const box = await panel.boundingBox();
  if (!box) throw new Error('Price panel had no bounding box — selector likely wrong, verify SELECTORS.pricePanel.');

  const targetX = box.x + box.width / 2;
  const targetY = box.y + box.height / 2;

  // Start from a plausible current position and step toward the target
  // in several small moves (>=8) rather than one jump.
  const steps = 10;
  const startX = Math.max(0, targetX - 250);
  const startY = Math.max(0, targetY - 150);

  await page.mouse.move(startX, startY);
  for (let i = 1; i <= steps; i++) {
    const x = startX + ((targetX - startX) * i) / steps;
    const y = startY + ((targetY - startY) * i) / steps;
    await page.mouse.move(x, y, { steps: 3 });
    await page.waitForTimeout(60); // small human-like pause between moves
  }

  console.log(`[mouse] Simulated ${steps} mouse-move steps toward the price panel.`);

  // Now hold over the panel for 600ms+.
  await page.waitForTimeout(750);
  console.log('[mouse] Held hover over price panel for 750ms (>600ms threshold).');
}

/**
 * Clicks "Check today's price" once it's enabled.
 */
async function clickCheckPrice(page) {
  const btn = page.locator(SELECTORS.checkPriceButton).first();
  await btn.waitFor({ state: 'visible', timeout: 10000 });

  const isDisabled = await btn.isDisabled().catch(() => false);
  if (isDisabled) {
    // Give the behavioral gate a moment to unlock after our mouse activity.
    await page.waitForTimeout(500);
  }

  await btn.click({ timeout: 5000 });
  console.log('[click] Clicked "Check today\'s price".');
}

/**
 * Waits for EITHER the success state or the error state to render —
 * never a fixed timer. Returns a structured result; never guesses or
 * fabricates price/stock.
 */
async function waitForPriceResult(page) {
  const success = page.locator(SELECTORS.priceSuccessState).first();
  const error = page.locator(SELECTORS.priceErrorState).first();

  const outcome = await Promise.race([
    success.waitFor({ state: 'visible', timeout: TIMEOUTS.priceResolve }).then(() => 'success'),
    error.waitFor({ state: 'visible', timeout: TIMEOUTS.priceResolve }).then(() => 'error'),
  ]).catch(() => 'timeout');

  if (outcome === 'success') {
    const priceText = await page.locator(SELECTORS.priceValue).first().textContent().catch(() => null);
    const stockText = await page.locator(SELECTORS.stockValue).first().textContent().catch(() => null);
    return {
      outcome: 'success',
      price: priceText ? priceText.trim() : null,
      stock: stockText ? stockText.trim() : null,
    };
  }

  if (outcome === 'error') {
    const errorText = await page.locator(SELECTORS.priceErrorState).first().textContent().catch(() => null);
    return { outcome: 'failed', price: null, stock: null, detail: errorText ? errorText.trim() : 'error state shown' };
  }

  // Neither state rendered in time — this is the ~35% "does nothing" case,
  // or a genuinely slow response beyond our wait window.
  return { outcome: 'failed', price: null, stock: null, detail: 'timed out waiting for success/error state' };
}

// ---------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------
async function scrapeOnce() {
  const browser = await chromium.launch({ headless: HEADLESS });
  const context = await browser.newContext();
  const page = await context.newPage();

  const url = `${STORE_BASE_URL}${PRODUCT_PATH}`;
  console.log(`[nav] Navigating to ${url}`);
  await page.goto(url, { waitUntil: 'domcontentloaded' });

  const result = { url, timestamp: new Date().toISOString() };

  try {
    await dismissCookieConsentIfPresent(page);
    await simulateGenuineMouseMovement(page);
    await clickCheckPrice(page);
    const priceResult = await waitForPriceResult(page);
    Object.assign(result, priceResult);
  } catch (err) {
    result.outcome = 'failed';
    result.price = null;
    result.stock = null;
    result.detail = `script error: ${err.message}`;
  }

  console.log('\n=== SCRAPE RESULT ===');
  console.log(JSON.stringify(result, null, 2));

  await browser.close();
  return result;
}

scrapeOnce().catch((err) => {
  console.error('Fatal error running scraper:', err);
  process.exit(1);
});
